﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace AuthorsSite
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ManagementConnectionString"].ConnectionString);
            SqlCommand comm = new SqlCommand();

            comm.CommandText = "InsertNewABroker";
            comm.CommandType = CommandType.StoredProcedure;
            comm.Connection = conn;

            SqlParameter brokerid = new SqlParameter("BrokerID", broid.Text);
            SqlParameter firstNameParam = new SqlParameter("firstName", FirstName.Text);
            SqlParameter lastNameParam = new SqlParameter("lastName", LastName.Text);
            SqlParameter brokercompany = new SqlParameter("brokercompany", broco.Text);
            SqlParameter brokerfee = new SqlParameter("brokerfee", bofa.Text);

            comm.Parameters.Add(brokerid);
            comm.Parameters.Add(firstNameParam);
            comm.Parameters.Add(lastNameParam);
            comm.Parameters.Add(brokercompany);
            comm.Parameters.Add(brokerfee);

            SqlParameter returnParam = new SqlParameter();
            returnParam.ParameterName = "returnValue";
            returnParam.Direction = ParameterDirection.ReturnValue;
            comm.Parameters.Add(returnParam);

            conn.Open();
            comm.ExecuteNonQuery();
            conn.Close();

            if (comm.Parameters["returnValue"].Value.ToString() == "0")
                Label1.Text = "There was an error in the stored procedure";

            GridView1.DataBind();
        }





        protected void Button4_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ManagementConnectionString"].ConnectionString);
            SqlCommand comm = new SqlCommand();

            comm.CommandText = "InsertNewLandlord";
            comm.CommandType = CommandType.StoredProcedure;
            comm.Connection = conn;

            SqlParameter lanid = new SqlParameter("Landlordid",laniid.Text);
            SqlParameter firstNameParam = new SqlParameter("FirstName", firstname1.Text);
            SqlParameter lastNameParam = new SqlParameter("LastName", lastname1.Text);
            SqlParameter phone = new SqlParameter("PhoneNo", phn.Text);
            SqlParameter email = new SqlParameter("Email", ema.Text);

            comm.Parameters.Add(lanid);
            comm.Parameters.Add(firstNameParam);
            comm.Parameters.Add(lastNameParam);
            comm.Parameters.Add(phone);
            comm.Parameters.Add(email);

            SqlParameter returnParam = new SqlParameter();
            returnParam.ParameterName = "returnValue";
            returnParam.Direction = ParameterDirection.ReturnValue;
            comm.Parameters.Add(returnParam);

            conn.Open();
            comm.ExecuteNonQuery();
            conn.Close();

            if (comm.Parameters["returnValue"].Value.ToString() == "0")
                Label2.Text = "There was an error in the stored procedure";

            GridView1.DataBind();
        }






        protected void Button5_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ManagementConnectionString"].ConnectionString);
            SqlCommand comm = new SqlCommand();

            comm.CommandText = "InsertNewCUSTOMER";
            comm.CommandType = CommandType.StoredProcedure;
            comm.Connection = conn;

            SqlParameter custid = new SqlParameter("CustomerId", custtd.Text);
            SqlParameter firstName1 = new SqlParameter("FirstName", fname.Text);
            SqlParameter lastName2 = new SqlParameter("LastName", lname.Text);
            SqlParameter identype = new SqlParameter("IdentificationType", idetype1.Text);
            SqlParameter idenno = new SqlParameter("IdentificationNo", ideno1.Text);
            SqlParameter occup = new SqlParameter("Occupation", occ.Text);
            SqlParameter email = new SqlParameter("Email", email1.Text);
            SqlParameter phonen = new SqlParameter("Phone", phono.Text);
            SqlParameter currte = new SqlParameter("CurrentTenant", curtena.Text);
            SqlParameter brokid = new SqlParameter("BrokerID", brokeid.Text);

            comm.Parameters.Add(custid);
            comm.Parameters.Add(firstName1);
            comm.Parameters.Add(lastName2);
            comm.Parameters.Add(identype);
            comm.Parameters.Add(idenno);
            comm.Parameters.Add(occup);
            comm.Parameters.Add(email);
            comm.Parameters.Add(phonen);
            comm.Parameters.Add(currte);
            comm.Parameters.Add(brokid);


            SqlParameter returnParam = new SqlParameter();
            returnParam.ParameterName = "returnValue";
            returnParam.Direction = ParameterDirection.ReturnValue;
            comm.Parameters.Add(returnParam);

            conn.Open();
            comm.ExecuteNonQuery();
            conn.Close();

            if (comm.Parameters["returnValue"].Value.ToString() == "0")
                Label3.Text = "There was an error in the stored procedure";

            GridView1.DataBind();
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ManagementConnectionString"].ConnectionString);
            SqlCommand comm = new SqlCommand();

            comm.CommandText = "DeleteBroker";
            comm.CommandType = CommandType.StoredProcedure;
            comm.Connection = conn;

            SqlParameter delbroker = new SqlParameter("BrokerID", DeleteBroker.Text);

            comm.Parameters.Add(delbroker);

            SqlParameter returnParam = new SqlParameter();
            returnParam.ParameterName = "returnValue";
            returnParam.Direction = ParameterDirection.ReturnValue;
            comm.Parameters.Add(returnParam);

            conn.Open();
            comm.ExecuteNonQuery();
            conn.Close();

            if (comm.Parameters["returnValue"].Value.ToString() == "0")
                Label5.Text = "There was an error in the stored procedure";

            GridView1.DataBind();
        }

        protected void Button6_Click1(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ManagementConnectionString"].ConnectionString);
            SqlCommand comm = new SqlCommand();

            comm.CommandText = "DeleteLandlord";
            comm.CommandType = CommandType.StoredProcedure;
            comm.Connection = conn;

            SqlParameter dellandlord = new SqlParameter("LandlordID", DeleteLandlord.Text);

            comm.Parameters.Add(dellandlord);

            SqlParameter returnParam = new SqlParameter();
            returnParam.ParameterName = "returnValue";
            returnParam.Direction = ParameterDirection.ReturnValue;
            comm.Parameters.Add(returnParam);

            conn.Open();
            comm.ExecuteNonQuery();
            conn.Close();

            if (comm.Parameters["returnValue"].Value.ToString() == "0")
                delLabel.Text = "There was an error in the stored procedure";

            GridView1.DataBind();
        }

        protected void Button6_Click2(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ManagementConnectionString"].ConnectionString);
            SqlCommand comm = new SqlCommand();

            comm.CommandText = "InsertNewLandlordAddress";
            comm.CommandType = CommandType.StoredProcedure;
            comm.Connection = conn;

            SqlParameter laddid = new SqlParameter("L_addressID", L_addressID.Text);
            SqlParameter lid = new SqlParameter("LandlordID", LandID.Text);
            SqlParameter sno = new SqlParameter("StreetNumber", Streetnum.Text);
            SqlParameter street = new SqlParameter("Street", Street.Text);
            SqlParameter zip = new SqlParameter("Zip", Zip.Text);
            SqlParameter city = new SqlParameter("City", City.Text);
            SqlParameter state = new SqlParameter("State", State.Text);
           
           

            comm.Parameters.Add(laddid);
            comm.Parameters.Add(lid);
            comm.Parameters.Add(sno);
            comm.Parameters.Add(street);
            comm.Parameters.Add(zip);
            comm.Parameters.Add(city);
            comm.Parameters.Add(state);
           
          


            SqlParameter returnParam = new SqlParameter();
            returnParam.ParameterName = "returnValue";
            returnParam.Direction = ParameterDirection.ReturnValue;
            comm.Parameters.Add(returnParam);

            conn.Open();
            comm.ExecuteNonQuery();
            conn.Close();

            if (comm.Parameters["returnValue"].Value.ToString() == "0")
                Label6.Text = "There was an error in the stored procedure";

            GridView1.DataBind();
        }
    }
}